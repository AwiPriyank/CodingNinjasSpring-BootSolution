package com.example.todocrud.services;

import com.example.todocrud.entity.Todo;
import com.example.todocrud.entity.Users;
import com.example.todocrud.repository.ToDoRepository;
import com.example.todocrud.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TodoServices {

    @Autowired
     UserServices userServices;
    @Autowired
    ToDoRepository toDoRepository;
    @Autowired
     UserRepository userRepository;

    public Todo getTodoById(Long todoId){
        return toDoRepository.findById(todoId).orElse(null);
    }

    public Todo addTodo(Long userId, Todo todo) {
        Users user = userRepository.findById(userId).orElse(null);
        if (user != null) {
            user.getTodoList().add(todo);
            userRepository.save(user);
            return todo;
        }
        return null;
    }
    
    
    public Long deleteTodo(Long userId, Long todoId) {
        Users user = userRepository.findById(userId).orElse(null);
        if (user != null) {
            Todo todoToDelete = null;
            for (Todo todo : user.getTodoList()) {
                if (todoId.equals(todo.getId())) {
                    todoToDelete = todo;
                    break;
                }
            }

            if (todoToDelete != null) {
                user.getTodoList().remove(todoToDelete);
                userRepository.save(user);
                toDoRepository.deleteById(todoId);
                return todoId;
            } else {
                throw new RuntimeException("Todo not found in the user's todo list");
            }
        } else {
            throw new RuntimeException("User not found");
        }
    
    }
    

    public void toggleTodoCompleted(Long todoId){
        Todo todo = this.getTodoById(todoId);
        todo.setCompleted(!todo.getCompleted());
        toDoRepository.save(todo);
    }

    public void updateTodo(Todo todo) {
        toDoRepository.save(todo);
    }

}
